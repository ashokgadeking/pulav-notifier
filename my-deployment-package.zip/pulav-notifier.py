import requests
import re
# import json

def findPulav():

	headers = {
	'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.12; rv:55.0) Gecko/20100101 Firefox/55.0',
	}

	page = requests.get("https://www.santhiskitchens.com/menu", headers=headers).text

	if re.search(r'\bPulav\b', page):
	    print('Pulav available')

def lambda_handler(event, context):

    findPulav()

    # TODO implement
    # return {
    #     'statusCode': 200,
    #     'body': json.dumps('Hello from Lambda!')
    # }